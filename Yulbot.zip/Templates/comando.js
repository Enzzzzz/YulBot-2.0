const { ApplicationCommandType, ApplicationCommandOptionType } = require('discord.js');

module.exports = {
    name: '',
    description: "",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
          name: "",
          type: ApplicationCommandOptionType.String,
          description: "",
          required: true,
          choices: [
            {
              name: "",
              value: ""
            },
            {
              name: "",
              value: ""
            },
          ]
        }
    ],
    userPerms: [],
    botPerms: [],
    ownerOnly: true,
    run: async (client, interaction) => {

    }
};
