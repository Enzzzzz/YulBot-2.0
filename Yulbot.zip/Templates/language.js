const A = {
  en: {

  },
  pt: {
    
  },
  cn: {

  },
};
module.exports = { A };
