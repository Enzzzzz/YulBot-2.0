const client = require('..');

client.on("", async () => {
});